<?php
include 'includes/config.php';
include 'includes/database.php';

$db = new Database();

// File upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['media'])) {
    $uploadDir = 'uploads/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $file = $_FILES['media'];
    $fileName = time() . '_' . basename($file['name']);
    $targetPath = $uploadDir . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        $fileUrl = '/Fontys/Personal%20project/CMS/portfolio_test/bk-admin-2/uploads/' . $fileName;
        $db->query(
            "INSERT INTO media (file_name, file_url, file_type) VALUES (?, ?, ?)",
            [$fileName, $fileUrl, $file['type']]
        );
    }
}

// Media delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    // Set header to JSON
    header('Content-Type: application/json');
    //Try catch to prevent crash if the file is not found
    try {
        $id = $_POST['delete_id'];
        $media = $db->query("SELECT * FROM media WHERE id = ?", [$id])->fetch(PDO::FETCH_ASSOC);
        if ($media) {
            $db->query("DELETE FROM media WHERE id = ?", [$id]);
            
            // Delete the file from server
            $filePath = $_SERVER['DOCUMENT_ROOT'] . $media['file_url'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Media not found']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    exit;
}

$media = $db->query("SELECT * FROM media ORDER BY uploaded_at DESC")->fetchAll(PDO::FETCH_ASSOC);


if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
    include 'includes/admin-header.php';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Media Library</title>
    <link rel="stylesheet" href="public/css/style-admin.css">
    <base href="https://localhost/Fontys/Personal%20project/CMS/portfolio_test/bk-admin-2/">
</head>
<body>
    <main>
        <h1>Media Library</h1>

        <form class="upload-form" method="POST" enctype="multipart/form-data">
            <input type="file" name="media" accept="image/*" required>
            <button type="submit">Upload</button>
        </form>

        <div class="media-grid">
            <?php foreach ($media as $item): ?>
                <div class="media-item" data-id="<?php echo htmlspecialchars($item['id']); ?>" data-url="<?php echo htmlspecialchars($item['file_url']); ?>">
                    <img src="<?php echo htmlspecialchars($item['file_url']); ?>" 
                         alt="<?php echo htmlspecialchars($item['file_name']); ?>">
                    <button type="button" class="remove pri-cta">X</button>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Modal for image selection -->
        <div id="imageModal">
            <div class="modal-content">
                <h2>Select Image</h2>
                <div class="media-grid">
                    <?php foreach ($media as $item): ?>
                        <div class="media-item" data-url="<?php echo htmlspecialchars($item['file_url']); ?>">
                            <img src="<?php echo htmlspecialchars($item['file_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($item['file_name']); ?>">
                        </div>
                    <?php endforeach; ?>
                </div>
                <button id="selectImage">Select</button>
                <button id="cancelSelection">Cancel</button>
            </div>
        </div>
    </main>

    <script>
        // Function to create an image selector
        function createImageSelector(callback) {
            const modal = document.getElementById('imageModal');
            const mediaItems = modal.querySelectorAll('.media-item');
            const selectBtn = document.getElementById('selectImage');
            const cancelBtn = document.getElementById('cancelSelection');
            let selectedUrl = null;

            modal.style.display = 'block';
            mediaItems.forEach(item => {
                item.addEventListener('click', () => {
                    mediaItems.forEach(i => i.classList.remove('selected'));
                    item.classList.add('selected');
                    selectedUrl = item.dataset.url;
                });
            });

            selectBtn.onclick = () => {
                modal.style.display = 'none';
                if (selectedUrl && callback) {
                    callback(selectedUrl);
                }
            };

            cancelBtn.onclick = () => {
                modal.style.display = 'none';
            };
        }

        // Example of how to use the selector
        window.selectImage = function(inputId) {
            createImageSelector(url => {
                document.getElementById(inputId).value = url;
            });
        };

        document.addEventListener('DOMContentLoaded', function() {
            //Media delete function
            function handleMediaRemoval(button) {
                const mediaItem = button.closest('.media-item');
                const id = mediaItem.dataset.id;
                
                if (confirm('Weet je zeker dat je deze afbeelding wilt verwijderen?')) {
                    // Send AJAX request to delete the media item
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', 'media.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4) {
                            if (xhr.status === 200) {
                                try {
                                    const response = JSON.parse(xhr.responseText);
                                    if (response.success) {
                                        console.log('Media item deleted successfully');
                                        mediaItem.remove();
                                    } else {
                                        console.error('Error deleting media item:', response.message);
                                        alert('Er is een fout opgetreden bij het verwijderen van de afbeelding: ' + response.message);
                                    }
                                } catch (e) {
                                    console.error('Error parsing response:', e);
                                    console.log('Server response:', xhr.responseText);
                                    alert('Er is een fout opgetreden bij het verwerken van de server response. Controleer de console voor meer details.');
                                }
                            } else {
                                console.error('Error deleting media item. Status:', xhr.status);
                                console.log('Server response:', xhr.responseText);
                                alert('Er is een fout opgetreden bij het verwijderen van de afbeelding. Controleer de console voor meer details.');
                            }
                        }
                    };
                    xhr.send('delete_id=' + encodeURIComponent(id));
                }
            }

            // Add event listeners to existing remove buttons
            document.querySelectorAll('.remove').forEach(button => {
                button.addEventListener('click', function() {
                    handleMediaRemoval(this);
                });
            });
        });
    </script>
</body>
</html>
