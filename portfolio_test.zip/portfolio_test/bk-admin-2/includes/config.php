<?php
// Prevent multiple inclusion
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'bk-admin');
    
    // Base URL of your CMS
    define('BASE_URL', 'http://localhost/Fontys/Personal%20project/CMS/portfolio_test/');
}