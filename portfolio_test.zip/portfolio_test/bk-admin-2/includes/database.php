<?php
// Prevent multiple inclusion
if (!class_exists('Database')) {
    class Database {
        private $connection;
        
        public function __construct() {
            try {
                $this->connection = new PDO(
                    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
                    DB_USER,
                    DB_PASS
                );
                $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch(PDOException $e) {
                die("Connection failed: " . $e->getMessage());
            }
        }
        
        public function query($sql, $params = []) {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        }

        public function getPublishedPages() {
            return $this->query(
                "SELECT id, title, slug FROM pages WHERE status = 'published' ORDER BY title"
            )->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} 