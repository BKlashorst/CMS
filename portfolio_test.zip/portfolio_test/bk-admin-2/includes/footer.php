<?php
// Prevent multiple inclusion
if (!defined('FOOTER_INCLUDED')) {
    define('FOOTER_INCLUDED', true);
?>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> CMS. All rights reserved.</p>
    </footer>
</body>
</html>
<?php
}
?> 