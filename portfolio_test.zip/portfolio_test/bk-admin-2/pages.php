<?php
include 'includes/config.php';
include 'includes/database.php';
include 'includes/admin-header.php';

$db = new Database();

// Get all pages
$pages = $db->query("SELECT * FROM pages ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Page Management</title>
</head>

<body>
    <main>
        <h1>Pages</h1>
        <div class="btn-container">
            <a href="edit-pages.php" class="btn btn-primary">Create New Page</a>
        </div>

        <table class="pages-table">
            <thead class="pages-thead">
                <tr class="pages-tr">
                    <th>Title</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pages as $page): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($page['title']); ?></td>
                        <td><?php echo $page['status']; ?></td>
                        <td>
                            <a href="edit-pages.php?id=<?php echo $page['id']; ?>">Edit</a>
                            <a href="../page.php?slug=<?php echo $page['slug']; ?>" target="_blank">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>

</html>