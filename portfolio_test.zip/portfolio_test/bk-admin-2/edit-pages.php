<?php
include 'includes/config.php';
include 'includes/database.php';
include 'includes/admin-header.php';
$db = new Database();

// Debug: Log POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log('POST Data: ' . print_r($_POST, true));
}

// Define available block types
$blockTypes = [
    'text' => 'Text Block',
    'hero1' => 'Hero 1',
    'text-img' => 'Text & Image',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $slug = strtolower(str_replace(' ', '-', $title));

    // Update page
    if (empty($_POST['page_id'])) {
        $db->query(
            "INSERT INTO pages (title, slug, status) VALUES (?, ?, ?)",
            [$title, $slug, 'draft']
        );
        $pageId = $db->query("SELECT LAST_INSERT_ID() as id")->fetch(PDO::FETCH_ASSOC)['id'];
    } else {
        $pageId = $_POST['page_id'];
        $db->query(
            "UPDATE pages SET title = ?, slug = ? WHERE id = ?",
            [$title, $slug, $pageId]
        );

        // Clear existing content
        $db->query("DELETE FROM page_contents WHERE page_id = ?", [$pageId]);
    }

    // Process blocks
    if (isset($_POST['blocks']) && is_array($_POST['blocks'])) {
        foreach ($_POST['blocks'] as $index => $block) {
            if (empty($block['type']) || !isset($block['content'])) {
                error_log("Skipping invalid block at index " . $index);
                continue;
            }

            $settings = isset($block['settings']) ? json_encode($block['settings']) : null;

            $db->query(
                "INSERT INTO page_contents (page_id, content_type, content, sort_order, block_type, settings) 
                 VALUES (?, ?, ?, ?, ?, ?)",
                [$pageId, 'content', $block['content'], $index, $block['type'], $settings]
            );

            error_log("Successfully inserted block: " . $block['type'] . " with content: " . $block['content']);
        }
    }
}

$page = null;
$contents = [];
if (isset($_GET['id'])) {
    $page = $db->query(
        "SELECT * FROM pages WHERE id = ?",
        [$_GET['id']]
    )->fetch(PDO::FETCH_ASSOC);

    $contents = $db->query(
        "SELECT * FROM page_contents WHERE page_id = ? ORDER BY sort_order",
        [$_GET['id']]
    )->fetchAll(PDO::FETCH_ASSOC);
}
?>
<html>

<head>
    <title>Edit Page</title>
</head>

<body>
    <main>
        <h1><?php echo $page ? 'Edit Page' : 'Create New Page'; ?></h1>
        <form method="POST">
            <div class="dragElement" draggable="true">

                <?php if ($page): ?>
                    <input type="hidden" name="page_id" value="<?php echo $page['id']; ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" value="<?php echo $page ? htmlspecialchars($page['title']) : ''; ?>" required>
                </div>

                <div id="content-blocks">
                    <?php if ($page && $contents): ?>
                        <?php foreach ($contents as $index => $content): ?>
                            <div class="dropZone">
                                <div class="content-block <?php echo $content['block_type']; ?>-block">
                                    <input type="hidden" name="blocks[<?php echo $index; ?>][type]" value="<?php echo $content['block_type']; ?>">
                                    <div class="block-header">
                                        <h3><?php echo ucfirst($content['block_type']); ?></h3>
                                        <button type="button" class="remove-block">Remove</button>
                                    </div>
                                    <?php if ($content['block_type'] === 'hero1'): ?>
                                        <div class="form-group">
                                            <label>Title</label>
                                            <textarea
                                                id="wysiwyg-hero-<?php echo $index; ?>"
                                                name="blocks[<?php echo $index; ?>][content]"
                                                class="form-control wysiwyg-editor"
                                                rows="5"><?php echo htmlspecialchars($content['content']); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Background Image</label>
                                            <button type="button" class="select-media">Select Image</button>
                                            <input type="hidden" name="blocks[<?php echo $index; ?>][settings][bg_image]"
                                                class="selected-image"
                                                value="<?php echo htmlspecialchars(json_decode($content['settings'], true)['bg_image'] ?? ''); ?>" alt="Selected image">
                                            <div class="selected-image-preview"><?php if (!empty($content['settings'])): ?>
                                                    <img src="<?php echo htmlspecialchars(json_decode($content['settings'], true)['bg_image'] ?? ''); ?>" alt="Selected image">
                                                <?php endif; ?></div>
                                        </div>
                                    <?php elseif ($content['block_type'] === 'text'): ?>
                                        <div class="form-group">
                                            <label>Tekst</label>
                                            <textarea
                                                id="wysiwyg-text-<?php echo $index; ?>"
                                                name="blocks[<?php echo $index; ?>][content]"
                                                class="form-control wysiwyg-editor"
                                                rows="10"><?php echo htmlspecialchars($content['content']); ?></textarea>
                                        </div>
                                    <?php elseif ($content['block_type'] === 'text-img'): ?>
                                        <div class="form-group">
                                            <label>Tekst</label>
                                            <textarea
                                                id="wysiwyg-text-img-<?php echo $index; ?>"
                                                name="blocks[<?php echo $index; ?>][content]"
                                                class="form-control wysiwyg-editor"
                                                rows="10"><?php echo htmlspecialchars($content['content']); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Image</label>
                                            <button type="button" class="select-media">Select Image</button>
                                            <input type="hidden" name="blocks[<?php echo $index; ?>][settings][bg_image]"
                                                class="selected-image"
                                                value="<?php echo htmlspecialchars(json_decode($content['settings'], true)['bg_image'] ?? ''); ?>">
                                            <div class="selected-image-preview">
                                                <?php if (!empty($content['settings'])): ?>
                                                    <img src="<?php echo htmlspecialchars(json_decode($content['settings'], true)['bg_image'] ?? ''); ?>" alt="Selected image">
                                                <?php endif; ?>
                                            </div>
                                        <?php endif ?>
                                        </div>
                                </div>
                            </div>

                        <?php endforeach; ?>
                    <?php endif; ?>
                    <div class="dropZone"></div>
                </div>

                <div class="block-controls">
                    <select id="block-type">
                        <?php foreach ($blockTypes as $value => $label): ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="button" class="btn-primary" id="add-block">Add Content Block</button>
                </div>

                <button class="save" type="submit">Save Page</button>
        </form>
    </main>
</body>
<script>
    var dragItem = document.querySelector('.dragElement');
    var dropZoneSet = Array.from(document.querySelectorAll('.dropZone'));

    dropZoneSet.forEach(dropzone => {
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.appendChild(dragItem);
        });
    });

    dropZoneSet.forEach((dropZone) => {
        //hovering over
        dropZone.addEventListener('dragover', () => {
            dropZone.classList.add('hoverOver');
        });
        //no longer hovering over
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('hoverOver');
        });

    });

    dragItem.addEventListener('drag', () => {
        dragItem.classList.add('beingDragged');
    })


    dragItem.addEventListener('dragend', () => {
        dragItem.classList.remove('beingDragged');
    })

    // Add event listeners for all remove buttons (both existing and new blocks)
    document.addEventListener('DOMContentLoaded', function() {
        // Function to handle block removal
        function handleBlockRemoval(button) {
            const block = button.closest('.content-block');
            if (block) {
                block.remove();
            }
        }

        // Add event listeners to existing remove buttons
        document.querySelectorAll('.remove-block').forEach(button => {
            button.addEventListener('click', function() {
                handleBlockRemoval(this);
            });
        });

        // Add event listener for new blocks
        document.getElementById('add-block').addEventListener('click', function() {
            const blockType = document.getElementById('block-type').value;
            addBlock(blockType);
        });

        // Initialize drag and drop for content blocks
        initializeDragAndDrop();
    });

    function initializeDragAndDrop() {
        const contentBlocks = document.querySelectorAll('.content-block');
        const dropZones = document.querySelectorAll('.dropZone');

        // Make each content block draggable
        contentBlocks.forEach(block => {
            block.setAttribute('draggable', 'true');

            block.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', ''); // Required for Firefox
                this.classList.add('beingDragged');
            });

            block.addEventListener('dragend', function() {
                this.classList.remove('beingDragged');
            });
        });

        // Set up drop zones
        dropZones.forEach(zone => {
            zone.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('hoverOver');
            });

            zone.addEventListener('dragleave', function() {
                this.classList.remove('hoverOver');
            });

            zone.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('hoverOver');

                const draggedBlock = document.querySelector('.beingDragged');
                if (draggedBlock) {
                    // If the drop zone already has a block, swap them
                    if (this.children.length > 0) {
                        const existingBlock = this.children[0];
                        const draggedParent = draggedBlock.parentNode;

                        // Swap the blocks
                        draggedParent.appendChild(existingBlock);
                        this.appendChild(draggedBlock);
                    } else {
                        // If the drop zone is empty, just move the block
                        this.appendChild(draggedBlock);
                    }

                    // Update block indices
                    updateBlockIndices();
                }
            });
        });
    }

    // Function to update the indices of all blocks
    function updateBlockIndices() {
        const dropZones = document.querySelectorAll('.dropZone');
        let index = 0;

        dropZones.forEach(zone => {
            const block = zone.querySelector('.content-block');
            if (block) {
                // Update the hidden input for block type
                const typeInput = block.querySelector('input[name^="blocks"][name$="[type]"]');
                if (typeInput) {
                    typeInput.name = `blocks[${index}][type]`;
                }

                // Update the content textarea
                const contentTextarea = block.querySelector('textarea[name^="blocks"][name$="[content]"]');
                if (contentTextarea) {
                    contentTextarea.name = `blocks[${index}][content]`;
                }

                // Update the settings input
                const settingsInput = block.querySelector('input[name^="blocks"][name$="[settings]"]');
                if (settingsInput) {
                    settingsInput.name = `blocks[${index}][settings][bg_image]`;
                }

                // Update the ID of the wysiwyg editor
                const wysiwygEditor = block.querySelector('.wysiwyg-editor');
                if (wysiwygEditor) {
                    const blockType = typeInput ? typeInput.value : 'text';
                    wysiwygEditor.id = `wysiwyg-${blockType}-${index}`;
                }

                index++;
            }
        });
    }

    function addBlock(type) {
        const dropZones = document.querySelectorAll('.dropZone');
        let targetZone = null;

        // Find the first empty drop zone
        for (let i = 0; i < dropZones.length; i++) {
            if (dropZones[i].children.length === 0) {
                targetZone = dropZones[i];
                break;
            }
        }

        // If no empty drop zone found, use the last one
        if (!targetZone && dropZones.length > 0) {
            targetZone = dropZones[dropZones.length - 1];
        }

        if (!targetZone) {
            console.error('No drop zones found');
            return;
        }

        const index = document.querySelectorAll('.content-block').length;
        const block = document.createElement('div');
        block.className = `content-block ${type}-block`;
        block.draggable = true;

        switch (type) {
            case 'hero1':
                block.innerHTML = `
                <div class="content-block hero1-block">
                    <input type="hidden" name="blocks[${index}][type]" value="hero1">
                    <div class="block-header">
                        <h3>Hero 1</h3>
                        <button type="button" class="remove-block">Remove</button>
                    </div>
                    <div class="form-group">
                        <label>Heading</label>
                        <textarea 
                               id="wysiwyg-hero-${index}"
                               name="blocks[${index}][content]" 
                               class="form-control wysiwyg-editor"
                               rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Background Image</label>
                        <button type="button" class="select-media">Select Image</button>
                        <input type="hidden" name="blocks[${index}][settings][bg_image]" class="selected-image">
                        <div class="selected-image-preview"></div>
                    </div>
                </div>
            `;
                break;

            case 'text':
                block.innerHTML = `
                <div class="content-block text-block">
                    <input type="hidden" name="blocks[${index}][type]" value="text">
                    <div class="block-header">
                        <h3>Text Block</h3>
                        <button type="button" class="remove-block">Remove</button>
                    </div>
                    <div class="form-group">
                        <label>Tekst</label>
                        <textarea 
                               id="wysiwyg-text-${index}"
                               name="blocks[${index}][content]" 
                               class="form-control wysiwyg-editor"
                               rows="10"></textarea>
                    </div>
                </div>
            `;
                break;

            case 'text-img':
                block.innerHTML = `
                <div class="content-block tekst-img-block">
                    <input type="hidden" name="blocks[${index}][type]" value="text-img">
                    <div class="block-header">
                        <h3>Tekst & Image</h3>
                        <button type="button" class="remove-block">Remove</button>
                    </div>
                    <div class="form-group">
                        <label>Tekst</label>
                        <textarea 
                            id="wysiwyg-text-${index}"
                            name="blocks[${index}][content]" 
                            class="form-control wysiwyg-editor"
                            rows="10"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Image</label>
                        <button type="button" class="select-media">Select Image</button>
                        <input type="hidden" name="blocks[${index}][settings][bg_image]" class="selected-image">
                        <div class="selected-image-preview"></div>
                    </div>
                </div> 
            `;
                break;
        }

        targetZone.appendChild(block);

        // Add event listeners for the new block
        const removeButton = block.querySelector('.remove-block');
        if (removeButton) {
            removeButton.addEventListener('click', function() {
                handleBlockRemoval(this);
            });
        }

        const mediaButton = block.querySelector('.select-media');
        if (mediaButton) {
            mediaButton.addEventListener('click', function() {
                openMediaPicker(this);
            });
        }

        // Initialize TinyMCE for the new block
        const editor = block.querySelector('.wysiwyg-editor');
        if (editor) {
            tinymce.init({
                selector: '#' + editor.id,
                plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
                toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
                tinycomments_mode: 'embedded',
                tinycomments_author: 'Author name',
                mergetags_list: [{
                        value: 'First.Name',
                        title: 'First Name'
                    },
                    {
                        value: 'Email',
                        title: 'Email'
                    },
                ],
                ai_request: (request, respondWith) => respondWith.string(() => Promise.reject("See docs to implement AI Assistant")),
            });
        }
    }

    // Media Picker functionality
    function openMediaPicker(button) {
        const mediaPicker = document.createElement('div');
        mediaPicker.className = 'media-picker-modal';
        const originalBlock = button.closest('.content-block');

        // Fetch media from your existing functions.php
        fetch('includes/functions.php')
            .then(response => response.json())
            .then(media => {
                mediaPicker.innerHTML = `
                <div class="media-picker-content">
                    <div class="media-picker-header">
                        <h3>Select Media</h3>
                        <button type="button" class="close-media-picker">×</button>
                    </div>
                    <div class="media-picker-grid">
                        ${media.map(item => `
                            <div class="media-item" data-url="${item.filepath}">
                                <img src="${item.filepath}" alt="${item.filename}">
                                <p>${item.filename}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;

                document.body.appendChild(mediaPicker);

                // Add event listeners for media items
                mediaPicker.querySelectorAll('.media-item').forEach(item => {
                    item.addEventListener('click', function() {
                        const imageUrl = this.dataset.url;
                        const hiddenInput = originalBlock.querySelector('.selected-image');
                        const preview = originalBlock.querySelector('.selected-image-preview');

                        hiddenInput.value = imageUrl;
                        preview.innerHTML = `<img src="${imageUrl}" alt="Selected image">`;
                        mediaPicker.remove();
                    });
                });

                // Add event listener for close button
                const closeButton = mediaPicker.querySelector('.close-media-picker');
                closeButton.addEventListener('click', function() {
                    mediaPicker.remove();
                });
            });
    }

    document.querySelector('form').addEventListener('submit', function(e) {
        updateBlockIndices();
    });
</script>

</html>