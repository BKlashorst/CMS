<?php
include 'includes/config.php';
include 'includes/database.php';
include 'includes/admin-header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Posts</title>
    <link rel="stylesheet" href="public/css/style-admin.css">
</head>
<body>
    <main>
        <h1>Posts</h1>
    </main>
</body>
</html>
