<?php
include 'bk-admin-2/includes/config.php';
include 'bk-admin-2/includes/database.php';
include 'bk-admin-2/includes/header.php';

$db = new Database();
$slug = $_GET['slug'] ?? 'home';

// Get the page content
$page = $db->query(
    "SELECT * FROM pages WHERE slug = ? AND status = 'published'",
    [$slug]
)->fetch(PDO::FETCH_ASSOC);

if (!$page) {
    // Page not found
    header("HTTP/1.0 404 Not Found");
    echo "<h1>404 - Page Not Found</h1>";
    echo "<p>The page you are looking for does not exist.</p>";
    exit;
}

// Get page contents
$contents = $db->query(
    "SELECT * FROM page_contents WHERE page_id = ? ORDER BY sort_order",
    [$page['id']]
)->fetchAll(PDO::FETCH_ASSOC);
?>

<main>
    <?php foreach ($contents as $content): ?>
        <section>
            <div class="content-block <?php echo $content['block_type']; ?>-block">
                <?php if ($content['block_type'] === 'hero1'): ?>
                    <div class="hero-section">
                        <div class="hero1-dl-wrap">
                            <?php echo $content['content']; ?>
                        </div>
                        <div class="hero1-dr-wrap">
                            <div class="hero1-d-r-img-wrap">
                                <img src="<?php echo htmlspecialchars(json_decode($content['settings'], true)['bg_image'] ?? ''); ?>" alt="Hero Image">
                                
                            </div>
                        </div>
                    </div>
                <?php elseif ($content['block_type'] === 'text'): ?>
                    <div class="text-content">
                        <?php echo $content['content']; ?>
                    </div>
                <?php elseif($content['block_type'] === 'text-img'): ?>
                    <div class="text-img-section">
                        <div class="dl-t-img-wrap">
                            <?php echo $content['content']; ?>
                        </div>
                        <div class="dr-t-img-wrap">
                            <img src="<?php echo htmlspecialchars(json_decode($content['settings'], true)['bg_image'] ?? ''); ?>" alt="Image">
                        </div>
                    </div>

                <?php endif; ?>
                
            </div>
        </section>
    <?php endforeach; ?>
</main>

<?php include 'bk-admin-2/includes/footer.php'; ?>